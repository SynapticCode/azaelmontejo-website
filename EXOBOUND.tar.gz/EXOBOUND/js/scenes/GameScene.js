class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
        this.tutorialMode = true;
    }

    init() {
        this.gameDataManager = this.registry.get('gameDataManager');
        if (!this.gameDataManager) {
            console.error('GameDataManager not found in registry!');
        } else {
            console.log('GameScene initialized with GameDataManager');
        }
    }

    create() {
        console.log('GameScene create method started');
        
        // Create explosion animation with exact frame numbers
        this.anims.create({
            key: 'explosion_anim',
            frames: this.anims.generateFrameNumbers('explosion_sprite_strip', {
                frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
            }),
            frameRate: 20,
            repeat: 0
        });
        
        // Draw the static environment
        this.createBackground();
        this.createCockpit();
        this.createAsteroid();
        
        // Create tutorial-specific objects (initially hidden)
        this.createTutorialObjects();
        
        // Launch the UI layer scene
        this.scene.launch('TutorialUIScene');
        console.log('TutorialUIScene launched');
    }
    
    createBackground() {
        // Create starfield background
        this.starfield = this.add.tileSprite(0, 0, this.cameras.main.width, this.cameras.main.height, 'starfield');
        this.starfield.setOrigin(0, 0);
        this.starfield.setScrollFactor(0);
    }
    
    createCockpit() {
        // Add the cockpit frame with the correct asset name
        this.cockpit = this.add.image(0, 0, 'cockpit');
        this.cockpit.setOrigin(0, 0);
        this.cockpit.setDisplaySize(this.cameras.main.width, this.cameras.main.height);
        this.cockpit.setScrollFactor(0);
        this.cockpit.setDepth(10); // Make sure cockpit is in front of other elements
    }
    
    createAsteroid() {
        // Add the main asteroid in the distance with the correct asset name
        this.asteroid = this.add.image(
            this.cameras.main.width / 2,
            this.cameras.main.height / 2 - 50,
            'asteroid_large'  // Using the correct asset name
        );
        this.asteroid.setScale(0.5);
        this.asteroid.setAlpha(0.7); // Make it slightly transparent to indicate it's in the distance
        this.asteroid.setDepth(1);
    }
    
    createTutorialObjects() {
        try {
            // Create the tutorial raider (initially hidden) with the correct asset name
            this.tutorialRaider = this.add.image(
                this.cameras.main.width * 0.4,
                this.cameras.main.height * 0.5,
                'raider_red'  // Using the correct asset name
            );
            this.tutorialRaider.setScale(0.3);
            this.tutorialRaider.setDepth(2);
            this.tutorialRaider.setVisible(false);
            
            // Create the tutorial allied ships (initially hidden) with the correct asset names
            this.tutorialAllies = [];
            
            // Allied ship 1 (green)
            const ally1 = this.add.image(
                this.cameras.main.width * 0.3,
                this.cameras.main.height * 0.6,
                'allied_ship_green'  // Using the correct asset name
            );
            ally1.setScale(0.3);
            ally1.setDepth(11);
            ally1.setVisible(false);
            this.tutorialAllies.push(ally1);
            
            // Allied ship 2 (orange)
            const ally2 = this.add.image(
                this.cameras.main.width * 0.5,
                this.cameras.main.height * 0.7,
                'allied_ship_orange'  // Using the correct asset name
            );
            ally2.setScale(0.3);
            ally2.setDepth(2);
            ally2.setVisible(false);
            this.tutorialAllies.push(ally2);
            
            // Create the target markers (initially hidden)
            this.standardMarker = this.add.image(
                this.asteroid.x,
                this.asteroid.y,
                'standard_marker'
            );
            this.standardMarker.setScale(0.5);
            this.standardMarker.setDepth(3);
            this.standardMarker.setVisible(false);
            
            this.tacticalMarker = this.add.image(
                this.tutorialRaider.x,
                this.tutorialRaider.y,
                'standard_marker'
            );
            this.tacticalMarker.setScale(0.5);
            this.tacticalMarker.setDepth(3);
            this.tacticalMarker.setTint(0xff0000); // Red tint for tactical marker
            this.tacticalMarker.setVisible(false);
            
            console.log('Tutorial objects created successfully');
        } catch (error) {
            console.error('Error creating tutorial objects:', error);
        }
    }
    
    // Tutorial event functions called by TutorialUIScene
    focusTutorialAsteroid() {
        try {
            // Highlight the asteroid with a pulsing effect
            this.tweens.add({
                targets: this.asteroid,
                scale: 0.6,
                duration: 1000,
                yoyo: true,
                repeat: 1,
                ease: 'Sine.easeInOut'
            });
            console.log('Asteroid focus animation started');
        } catch (error) {
            console.error('Error in focusTutorialAsteroid:', error);
        }
    }
    
    showTutorialRaider() {
        try {
            // Show the raider ship with an entrance animation
            this.tutorialRaider.setVisible(true);
            this.tutorialRaider.setAlpha(0);
            this.tutorialRaider.setScale(0.1);
            
            // Animate the raider flying in
            this.tweens.add({
                targets: this.tutorialRaider,
                alpha: 1,
                scale: 0.3,
                x: this.cameras.main.width * 0.6,
                y: this.cameras.main.height * 0.5,
                duration: 1500,
                ease: 'Power2'
            });
            console.log('Raider animation started');
        } catch (error) {
            console.error('Error in showTutorialRaider:', error);
        }
    }
    
    showTutorialAllies() {
        try {
            // Show the allied ships with entrance animations
            this.tutorialAllies.forEach((ally, index) => {
                ally.setVisible(true);
                ally.setAlpha(0);
                ally.setScale(0.1);
                
                // Stagger the animations
                this.tweens.add({
                    targets: ally,
                    alpha: 1,
                    scale: 0.3,
                    x: index === 0 ? this.cameras.main.width * 0.2 : // Left window (green ship)
                    this.cameras.main.width * 0.8,  // Right window (orange ship)
                y: this.cameras.main.height * 0.5,  // 
                    duration: 1000,
                    delay: index * 500,
                    ease: 'Power2'
                });
            });
            console.log('Allies animation started');
        } catch (error) {
            console.error('Error in showTutorialAllies:', error);
        }
    }
    
    showTutorialTargetOptions() {
        try {
            // Show the standard and tactical markers
            this.standardMarker.setVisible(true);
            this.tacticalMarker.setVisible(true);
            
            // Add pulsing animation to both markers
            this.tweens.add({
                targets: [this.standardMarker, this.tacticalMarker],
                alpha: { from: 0.5, to: 1 },
                scale: { from: 0.4, to: 0.5 },
                duration: 1000,
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
            console.log('Target markers animation started');
        } catch (error) {
            console.error('Error in showTutorialTargetOptions:', error);
        }
    }
    
    prepareForMission() {
        try {
            // Final visual preparation before starting the real game
            // Pulse all elements one last time
            this.tweens.add({
                targets: [this.asteroid, this.tutorialRaider, ...this.tutorialAllies],
                alpha: { from: 0.7, to: 1 },
                duration: 1000,
                yoyo: true,
                repeat: 1,
                ease: 'Sine.easeInOut'
            });
            console.log('Final mission preparation animation started');
        } catch (error) {
            console.error('Error in prepareForMission:', error);
        }
    }
    
    startRealGame() {
        console.log('Starting the real game (Trial 1)');
        
        try {
            // Clean up tutorial objects
            this.tutorialRaider.setVisible(false);
            this.tutorialAllies.forEach(ally => ally.setVisible(false));
            this.standardMarker.setVisible(false);
            this.tacticalMarker.setVisible(false);
            
            // Set tutorial mode to false
            this.tutorialMode = false;
            
            // Start the first trial from the GameDataManager
            if (this.gameDataManager) {
                const trial = this.gameDataManager.setupTrial(0); // Start with trial index 0
                console.log('First trial set up from GameDataManager:', trial);
            } else {
                console.error('GameDataManager not available!');
            }
            
            // Launch the HUD scene for the real game
            this.scene.launch('HUDScene');
            console.log('HUDScene launched for real game');
        } catch (error) {
            console.error('Error in startRealGame:', error);
        }
    }
    
    createExplosion(x, y) {
        // Create an explosion sprite and play the animation
        const explosion = this.add.sprite(x, y, 'explosion_sprite_strip');
        explosion.play('explosion_anim');
        
        // Play explosion sound
        try {
            if (this.sound.get('explosionCrunch_002')) {
                this.sound.play('explosionCrunch_002', { volume: 0.7 });
            }
            if (this.sound.get('lowFrequency_explosion_000')) {
                this.sound.play('lowFrequency_explosion_000', { volume: 0.5 });
            }
        } catch (e) {
            console.warn('Error playing explosion sound:', e);
        }
        
        return explosion;
    }
    
    update() {
        // Slowly scroll the starfield for a space-travel effect
        this.starfield.tilePositionY -= 0.5;
        
        // If in tutorial mode, make the raider slowly move
        if (this.tutorialMode && this.tutorialRaider && this.tutorialRaider.visible) {
            this.tutorialRaider.x += Math.sin(this.time.now / 1000) * 0.5;
            this.tutorialRaider.y += Math.cos(this.time.now / 1000) * 0.3;
        }
    }
}

export default GameScene;
