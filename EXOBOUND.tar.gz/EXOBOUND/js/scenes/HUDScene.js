class HUDScene extends Phaser.Scene {
    constructor() {
        super({ key: 'HUDScene' });
        this.reticleActive = false;
    }

    init() {
        this.gameDataManager = this.registry.get('gameDataManager');
        if (!this.gameDataManager) {
            console.error('GameDataManager not found in registry!');
        }
    }

    create() {
        console.log('HUDScene create method started');
        
        // Get reference to the GameScene
        this.gameScene = this.scene.get('GameScene');
        
        // Create the reticle
        this.createReticle();
        
        // Create the laser effect (initially invisible)
        this.createLaserEffect();
        
        // Set up input handling
        this.setupInput();
    }
    
    createReticle() {
        // Add the reticle in the center of the screen
        this.reticle = this.add.image(
            this.cameras.main.width / 2,
            this.cameras.main.height / 2,
            'reticle'
        );
        this.reticle.setScale(0.5);
        this.reticle.setDepth(15);
        this.reticleActive = true;
        
        // Add a pulsing animation to the reticle
        this.tweens.add({
            targets: this.reticle,
            scale: 0.6,
            duration: 800,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    createLaserEffect() {
        // Create a laser beam effect (initially invisible)
        this.laserBeam = this.add.rectangle(
            this.cameras.main.width / 2,
            this.cameras.main.height / 2,
            10, // width
            this.cameras.main.height, // height (will be adjusted based on target)
            0x00ffff // cyan color
        );
        this.laserBeam.setOrigin(0.5, 0);
        this.laserBeam.setAlpha(0.8);
        this.laserBeam.setDepth(14); // Below reticle but above other elements
        this.laserBeam.setVisible(false);
    }
    
    setupInput() {
        // Set up click/tap input
        this.input.on('pointerdown', this.handlePlayerShot, this);
    }
    
    handlePlayerShot(pointer) {
        if (!this.reticleActive) return;
        
        // Determine what was shot
        let target = this.determineTarget();
        
        // Fire the laser
        this.fireLaser(target);
        
        // Disable further input temporarily
        this.reticleActive = false;
        
        // After a short delay, transition to the feedback scene
        this.time.delayedCall(1000, () => {
            this.scene.launch('FeedbackSceneV2', { target: target });
            this.scene.pause('GameScene');
            this.scene.pause('HUDScene');
        });
    }
    
    determineTarget() {
        // Get the positions of potential targets from the GameScene
        const asteroid = this.gameScene.asteroid;
        const raider = this.gameScene.tutorialMode ? this.gameScene.tutorialRaider : null;
        
        // In real game mode, get raiders from GameDataManager
        let raiders = [];
        if (!this.gameScene.tutorialMode && this.gameDataManager) {
            // Safely access alienFleet and filter active aliens
            if (this.gameDataManager.alienFleet && Array.isArray(this.gameDataManager.alienFleet)) {
                raiders = this.gameDataManager.alienFleet.filter(alien => alien && alien.status === 'active');
            } else {
                console.warn('alienFleet is not properly initialized in GameDataManager');
                raiders = [];
            }
        }
        
        // Check if we're aiming at the asteroid
        if (asteroid && Phaser.Geom.Rectangle.Contains(
            new Phaser.Geom.Rectangle(asteroid.x - asteroid.displayWidth/2, asteroid.y - asteroid.displayHeight/2, 
                                      asteroid.displayWidth, asteroid.displayHeight),
            this.reticle.x, this.reticle.y)) {
            return { type: 'asteroid', object: asteroid };
        }
        
        // Check if we're aiming at a raider in tutorial mode
        if (this.gameScene.tutorialMode && raider && raider.visible && 
            Phaser.Geom.Rectangle.Contains(
                new Phaser.Geom.Rectangle(raider.x - raider.displayWidth/2, raider.y - raider.displayHeight/2, 
                                          raider.displayWidth, raider.displayHeight),
                this.reticle.x, this.reticle.y)) {
            return { type: 'raider', object: raider, id: 'tutorial' };
        }
        
        // Check if we're aiming at a raider in real game mode
        for (let raider of raiders) {
            if (raider && raider.sprite && Phaser.Geom.Rectangle.Contains(
                new Phaser.Geom.Rectangle(raider.sprite.x - raider.sprite.displayWidth/2, 
                                          raider.sprite.y - raider.sprite.displayHeight/2, 
                                          raider.sprite.displayWidth, raider.sprite.displayHeight),
                this.reticle.x, this.reticle.y)) {
                return { type: 'raider', object: raider.sprite, id: raider.id };
            }
        }
        
        // Default to asteroid if nothing else is hit
        return { type: 'asteroid', object: asteroid };
    }
    
    fireLaser(target) {
        // Play laser sound
        try {
            if (this.sound.get('laserLarge_002')) {
                this.sound.play('laserLarge_002', { volume: 0.7 });
            }
            if (this.sound.get('laserRetro_001')) {
                this.sound.play('laserRetro_001', { volume: 0.7 });
            }
        } catch (e) {
            console.warn('Error playing laser sound:', e);
        }
        
        // Position and angle the laser based on target
        if (target && target.object) {
            // Calculate angle to target
            const angle = Phaser.Math.Angle.Between(
                this.cameras.main.width / 2,
                this.cameras.main.height / 2,
                target.object.x,
                target.object.y
            );
            
            // Calculate distance to target
            const distance = Phaser.Math.Distance.Between(
                this.cameras.main.width / 2,
                this.cameras.main.height / 2,
                target.object.x,
                target.object.y
            );
            
            // Set laser properties
            this.laserBeam.setVisible(true);
            this.laserBeam.setAngle(Phaser.Math.RadToDeg(angle) - 90); // -90 because rectangle is vertical
            this.laserBeam.height = distance;
            
            // Animate the laser
            this.tweens.add({
                targets: this.laserBeam,
                alpha: 0,
                duration: 500,
                ease: 'Power2',
                onComplete: () => {
                    this.laserBeam.setVisible(false);
                    this.laserBeam.setAlpha(0.8);
                }
            });
        }
    }
    
    update() {
        // Nothing needed in update for now
    }
}

export default HUDScene;
