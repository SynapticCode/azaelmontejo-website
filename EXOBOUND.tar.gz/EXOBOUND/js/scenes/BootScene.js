import AssetLoader from '../loaders/AssetLoader.js';

class BootScene extends Phaser.Scene {
    constructor() {
        super({ key: 'BootScene' });
    }

    preload() {
        console.log('BootScene: Delegating all asset loading to AssetLoader.js');
                
        // Create an instance of the asset loader and run it
        const assetLoader = new AssetLoader(this);
        assetLoader.loadAllAssets();

        // You can still have a loading bar here if you wish
        const progressBar = this.add.graphics();
        const progressBox = this.add.graphics();
        progressBox.fillStyle(0x333333, 0.8);
        progressBox.fillRect(320, 270, 320, 50);

        this.load.on('progress', function (value) {
            progressBar.clear();
            progressBar.fillStyle(0xffffff, 1);
            progressBar.fillRect(330, 280, 300 * value, 30);
        });
    }

    create() {
    console.log('BootScene: Loading complete. Starting GameScene.');

    // Get the loaded trials
    const trials = this.cache.json.get('trials');
    console.log('BootScene: Loaded trials:', trials);

    // Store in registry or a global manager
    this.registry.set('trials', trials);

    // Start the game scene
    this.scene.start('GameScene');
}

}

export default BootScene;
