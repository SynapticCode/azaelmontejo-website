class TutorialUIScene extends Phaser.Scene {
    constructor() {
        super({ key: 'TutorialUIScene' });
        
        // Define the tutorial script
        this.tutorialSteps = [
            {
                text: 'Welcome, Tactical Officer.\nLet\'s begin your mission briefing.\n\n(Click to continue)',
                event: null
            },
            {
                text: 'This is the main asteroid threatening our planet.\nIt must be destroyed before it reaches our atmosphere.\n\n(Click to continue)',
                event: 'focusAsteroid'
            },
            {
                text: 'Be warned: The asteroid periodically launches Raider ships\nthat will attack our fleet.\n\n(Click to continue)',
                event: 'showRaider'
            },
            {
                text: 'You are in command of our defensive fleet.\nYour decisions will determine our survival.\n\n(Click to continue)',
                event: 'showAllies'
            },
            {
                text: 'You must choose between:\n\nSTANDARD TARGET: Focus fire on the asteroid (safer)\nTACTICAL TARGET: Destroy Raiders to protect your fleet (riskier)\n\n(Click to continue)',
                event: 'showTargetOptions'
            },
            {
                text: 'You are now ready for your mission, Tactical Officer.\n\nGood luck. Earth is counting on you.\n\n(Click to Begin Mission)',
                event: 'prepareForMission'
            }
        ];
    }

    init() {
        this.currentStep = 0;
        console.log('TutorialUIScene initialized');
    }

    create() {
        console.log('TutorialUIScene created');
        
        // Make this scene transparent so the GameScene is visible underneath
        this.cameras.main.setBackgroundColor('rgba(0, 0, 0, 0)');
        
        // Create the tutorial text box
        this.tutorialText = this.add.text(
            this.cameras.main.width / 2, 
            this.cameras.main.height - 150,
            '',
            {
                fontFamily: 'Arial',
                fontSize: '24px',
                color: '#ffffff',
                align: 'center',
                stroke: '#000000',
                strokeThickness: 4,
                backgroundColor: 'rgba(0, 0, 0, 0.7)',
                padding: {
                    left: 20,
                    right: 20,
                    top: 20,
                    bottom: 20
                }
            }
        ).setOrigin(0.5);
        
        // Add a semi-transparent panel behind the text
        this.textPanel = this.add.rectangle(
            this.cameras.main.width / 2,
            this.cameras.main.height - 150,
            700,
            200,
            0x000000,
            0.7
        ).setOrigin(0.5);
        
        // Make sure the panel is behind the text
        this.textPanel.setDepth(1);
        this.tutorialText.setDepth(2);
        
        // Add click handler to advance through tutorial
        this.input.on('pointerdown', this.advanceTutorial, this);
        
        // Start with the first step
        this.showCurrentStep();
    }
    
    showCurrentStep() {
        // Get the current step data
        const step = this.tutorialSteps[this.currentStep];
        
        // Update the text
        this.tutorialText.setText(step.text);
        
        // Trigger the associated event if there is one
        if (step.event) {
            this.triggerEvent(step.event);
        }
    }
    
    advanceTutorial() {
        // Move to the next step
        this.currentStep++;
        
        // Check if we've reached the end of the tutorial
        if (this.currentStep >= this.tutorialSteps.length) {
            this.endTutorial();
            return;
        }
        
        // Show the next step
        this.showCurrentStep();
    }
    
    triggerEvent(eventName) {
        // Get a reference to the GameScene
        const gameScene = this.scene.get('GameScene');
        
        // Trigger the appropriate event based on the name
        switch(eventName) {
            case 'focusAsteroid':
                gameScene.focusTutorialAsteroid();
                break;
            case 'showRaider':
                gameScene.showTutorialRaider();
                break;
            case 'showAllies':
                gameScene.showTutorialAllies();
                break;
            case 'showTargetOptions':
                gameScene.showTutorialTargetOptions();
                break;
            case 'prepareForMission':
                gameScene.prepareForMission();
                break;
            default:
                console.warn(`Unknown event: ${eventName}`);
        }
    }
    
    endTutorial() {
        console.log('Tutorial completed, starting the real game');
        
        // Hide the tutorial UI
        this.tutorialText.setVisible(false);
        this.textPanel.setVisible(false);
        
        // Tell the GameScene to start the real game
        const gameScene = this.scene.get('GameScene');
        gameScene.startRealGame();
        
        // Stop this scene
        this.scene.stop();
    }
}

export default TutorialUIScene;
