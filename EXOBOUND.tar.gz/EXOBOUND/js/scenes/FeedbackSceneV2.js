class FeedbackSceneV2 extends Phaser.Scene {
    constructor() {
        super({ key: 'FeedbackSceneV2' });
    }

    init(data) {
        // Store the target data passed from HUDScene
        this.targetData = data.target || { type: 'asteroid' };
        console.log('FeedbackSceneV2 initialized with target data:', this.targetData);
        
        // Get reference to the GameDataManager
        this.gameDataManager = this.registry.get('gameDataManager');
        if (!this.gameDataManager) {
            console.error('GameDataManager not found in registry!');
        }
    }

    create() {
        console.log('FeedbackSceneV2 create method started');
        
        // Add tactical background
        this.createTacticalBackground();
        
        // Add fleet representations
        this.createFleetRepresentations();
        
        // Show the battle outcome
        this.showBattleOutcome();
        
        // Add continue button
        this.createContinueButton();
    }
    
    createTacticalBackground() {
        // Add a dark background with grid lines
        this.add.rectangle(0, 0, this.cameras.main.width, this.cameras.main.height, 0x000000)
            .setOrigin(0, 0);
            
        // Add grid lines
        const graphics = this.add.graphics();
        graphics.lineStyle(1, 0x333333, 0.8);
        
        // Draw horizontal grid lines
        for (let y = 0; y < this.cameras.main.height; y += 50) {
            graphics.beginPath();
            graphics.moveTo(0, y);
            graphics.lineTo(this.cameras.main.width, y);
            graphics.closePath();
            graphics.strokePath();
        }
        
        // Draw vertical grid lines
        for (let x = 0; x < this.cameras.main.width; x += 50) {
            graphics.beginPath();
            graphics.moveTo(x, 0);
            graphics.lineTo(x, this.cameras.main.height);
            graphics.closePath();
            graphics.strokePath();
        }
    }
    
    createFleetRepresentations() {
        // Create player fleet icons at the bottom
        this.playerShips = [];
        
        // Get player fleet data from GameDataManager if available
        let fleetData = [];
        if (this.gameDataManager && this.gameDataManager.playerFleet) {
            fleetData = this.gameDataManager.playerFleet;
        } else {
            // Default fleet if GameDataManager is not available
            fleetData = [
                { id: 0, status: 'active', type: 'allied_ship_green' },
                { id: 1, status: 'active', type: 'allied_ship_blue' },
                { id: 2, status: 'active', type: 'allied_ship_orange' }
            ];
        }
        
        // Position the ships at the bottom of the screen
        const shipSpacing = 100;
        const startX = this.cameras.main.width / 2 - ((fleetData.length - 1) * shipSpacing) / 2;
        
        fleetData.forEach((ship, index) => {
            const shipIcon = this.add.image(
                startX + index * shipSpacing,
                this.cameras.main.height - 100,
                ship.type
            );
            shipIcon.setScale(0.3);
            shipIcon.setData('id', ship.id);
            shipIcon.setData('status', ship.status);
            
            // If the ship is already destroyed, show it as such
            if (ship.status === 'destroyed') {
                shipIcon.setAlpha(0.3);
                shipIcon.setTint(0x555555);
            }
            
            this.playerShips.push(shipIcon);
        });
        
        // Create enemy representation
        if (this.targetData.type === 'raider') {
            // Position the raider in the upper part of the screen
            this.enemyShip = this.add.image(
                this.cameras.main.width / 2,
                150,
                this.targetData.object ? this.targetData.object.texture.key : 'raider_red'
            );
            this.enemyShip.setScale(0.4);
        }
        
        // Create asteroid representation
        this.asteroid = this.add.image(
            this.cameras.main.width / 2,
            200,
            'asteroid_large'
        );
        this.asteroid.setScale(0.6);
        
        // If the target was not the asteroid, make it less prominent
        if (this.targetData.type !== 'asteroid') {
            this.asteroid.setAlpha(0.5);
        }
    }
    
    showBattleOutcome() {
        // Determine which ships are coordinated vs. uncoordinated
        // For simplicity, we'll say 70% of ships follow the player's choice
        const coordinatedShips = [];
        const uncoordinatedShips = [];
        
        this.playerShips.forEach((ship, index) => {
            if (ship.getData('status') === 'destroyed') return;
            
            // 70% chance to be coordinated
            if (Math.random() < 0.7) {
                coordinatedShips.push(ship);
            } else {
                uncoordinatedShips.push(ship);
            }
        });
        
        // Show laser fire from coordinated ships to player's target
        this.time.delayedCall(500, () => {
            this.fireLasers(coordinatedShips, this.targetData.type === 'asteroid' ? this.asteroid : this.enemyShip, 0x00ff00);
        });
        
        // Show laser fire from uncoordinated ships to asteroid (default target)
        this.time.delayedCall(800, () => {
            this.fireLasers(uncoordinatedShips, this.asteroid, 0xffff00);
        });
        
        // If the target was a raider, show its destruction
        if (this.targetData.type === 'raider' && this.enemyShip) {
            this.time.delayedCall(1500, () => {
                // Create explosion at raider position
                const explosion = this.add.sprite(this.enemyShip.x, this.enemyShip.y, 'explosion_sprite_strip')
                    .play('explosion_anim')
                    .setDepth(15);
                
                // Hide the raider
                this.enemyShip.setVisible(false);
                
                // Play explosion sound
                this.sound.play('explosionCrunch_002', { volume: 0.7 });
                this.sound.play('lowFrequency_explosion_000', { volume: 0.5 });
            });
        }
        
        // If there are still active raiders, show counter-attack
        if (this.targetData.type === 'asteroid' && this.enemyShip) {
            this.time.delayedCall(2000, () => {
                // Pick a random ship to attack
                const activeShips = this.playerShips.filter(ship => ship.getData('status') !== 'destroyed');
                if (activeShips.length > 0) {
                    const targetShip = Phaser.Utils.Array.GetRandom(activeShips);
                    
                    // Fire laser from raider to ship
                    this.fireLaser(this.enemyShip, targetShip, 0xff0000);
                    
                    // After laser hits, destroy the ship
                    this.time.delayedCall(500, () => {
                        // Create explosion at ship position
                        const explosion = this.add.sprite(targetShip.x, targetShip.y, 'explosion_sprite_strip')
                            .play('explosion_anim')
                            .setDepth(15);
                        
                        // Mark ship as destroyed
                        targetShip.setData('status', 'destroyed');
                        targetShip.setAlpha(0.3);
                        targetShip.setTint(0x555555);
                        
                        // Update GameDataManager
                        if (this.gameDataManager) {
                            this.gameDataManager.destroyFriendlyShip(targetShip.getData('id'));
                        }
                        
                        // Play explosion sound
                        this.sound.play('explosionCrunch_002', { volume: 0.7 });
                        this.sound.play('lowFrequency_explosion_000', { volume: 0.5 });
                    });
                }
            });
        }
        
        // Show damage to asteroid
        this.time.delayedCall(2500, () => {
            // Calculate damage based on how many ships targeted the asteroid
            const totalShips = this.playerShips.length;
            const shipsTargetingAsteroid = uncoordinatedShips.length + (this.targetData.type === 'asteroid' ? coordinatedShips.length : 0);
            this.bonus = shipsTargetingAsteroid / totalShips; // Calculate bonus as a percentage
            
            // Define damageAmount before using it
            const damageAmount = Math.round(this.bonus * 100);
            
            // Update asteroid health in GameDataManager
            if (this.gameDataManager) {
                this.gameDataManager.damageAsteroid(damageAmount);
            }
            
            // Visual feedback for asteroid damage
            if (damageAmount > 0) {
                this.tweens.add({
                    targets: this.asteroid,
                    alpha: 0.7,
                    scale: this.asteroid.scale * 0.9,
                    duration: 300,
                    yoyo: false
                });
            }
        });
        
        // Show results text
        this.time.delayedCall(3000, () => {
            // Create results container
            const resultsContainer = this.add.container(this.cameras.main.width / 2, this.cameras.main.height / 2);
            
            // Background panel
            const panel = this.add.rectangle(0, 0, 400, 200, 0x000000, 0.8);
            panel.setStrokeStyle(2, 0x3399ff);
            resultsContainer.add(panel);
            
            // Results text
            let threatNeutralized = 0;
            if (this.targetData.type === 'raider') {
                threatNeutralized = 100; // Full points for destroying a raider
            } else {
                // Calculate based on asteroid damage
                threatNeutralized = Math.min(100, Math.floor((damageAmount / 100) * 100));
            }
            
            // Calculate fleet integrity (percentage of ships still active)
            const fleetIntegrity = Math.floor((this.playerShips.filter(ship => ship.getData('status') !== 'destroyed').length / this.playerShips.length) * 100);
            
            // Add text to the container
            const titleText = this.add.text(0, -70, 'MISSION RESULTS', { 
                fontFamily: 'Arial', 
                fontSize: 24, 
                color: '#ffffff',
                align: 'center'
            }).setOrigin(0.5);
            
            const threatText = this.add.text(0, -20, `Threat Neutralized: ${threatNeutralized}%`, { 
                fontFamily: 'Arial', 
                fontSize: 18, 
                color: '#ffffff' 
            }).setOrigin(0.5);
            
            const fleetText = this.add.text(0, 20, `Fleet Integrity: ${fleetIntegrity}%`, { 
                fontFamily: 'Arial', 
                fontSize: 18, 
                color: '#ffffff' 
            }).setOrigin(0.5);
            
            resultsContainer.add([titleText, threatText, fleetText]);
            
            // Animate the container
            resultsContainer.setAlpha(0);
            this.tweens.add({
                targets: resultsContainer,
                alpha: 1,
                duration: 500,
                ease: 'Power2'
            });
        });
    }
    
    fireLasers(ships, target, color) {
        ships.forEach(ship => {
            this.fireLaser(ship, target, color);
        });
        
        // Play laser sound
        this.sound.play('laserLarge_002', { volume: 0.5 });
    }
    
    fireLaser(source, target, color) {
        const laser = this.add.line(
            0, 0,
            source.x, source.y,
            target.x, target.y,
            color
        );
        laser.setLineWidth(2);
        laser.setOrigin(0, 0);
        
        // Add glow effect
        laser.setBlendMode(Phaser.BlendModes.ADD);
        
        // Animate the laser
        this.tweens.add({
            targets: laser,
            alpha: 0,
            duration: 300,
            ease: 'Power2',
            onComplete: () => {
                laser.destroy();
            }
        });
    }
    
    createContinueButton() {
        // Add continue button after a delay
        this.time.delayedCall(4000, () => {
            const continueButton = this.add.text(
                this.cameras.main.width / 2,
                this.cameras.main.height - 50,
                'CONTINUE',
                {
                    fontFamily: 'Arial',
                    fontSize: 24,
                    color: '#ffffff',
                    backgroundColor: '#3366cc',
                    padding: { x: 20, y: 10 }
                }
            ).setOrigin(0.5);
            
            continueButton.setInteractive({ useHandCursor: true });
            
            // Add hover effect
            continueButton.on('pointerover', () => {
                continueButton.setBackgroundColor('#4477dd');
            });
            
            continueButton.on('pointerout', () => {
                continueButton.setBackgroundColor('#3366cc');
            });
            
            // Add click handler
            continueButton.on('pointerdown', () => {
                // Play click sound
                this.sound.play('sfx_ui_click');
                
                // Resume the game scenes
                this.scene.resume('GameScene');
                this.scene.resume('HUDScene');
                
                // Close this scene
                this.scene.stop();
            });
            
            // Animate button appearance
            continueButton.setAlpha(0);
            this.tweens.add({
                targets: continueButton,
                alpha: 1,
                y: this.cameras.main.height - 60,
                duration: 500,
                ease: 'Power2'
            });
        });
    }
}

export default FeedbackSceneV2;
