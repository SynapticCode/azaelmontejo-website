import BootScene from './scenes/BootScene.js';
import GameScene from './scenes/GameScene.js';
import HUDScene from './scenes/HUDScene.js';
import FeedbackSceneV2 from './scenes/FeedbackSceneV2.js';
import TutorialUIScene from './scenes/TutorialUIScene.js';
import GameDataManager from './GameDataManager.js';

// Create a single, global instance of the data manager
const gameDataManager = new GameDataManager();

// Initialize jsPsych
const jsPsych = initJsPsych({
    on_finish: function() {
        console.log('Experiment finished');
        const finalGameState = gameDataManager.getGameState();
        console.log('Final game state:', finalGameState);
        // You could add code here to save the data to a server or database
    }
});

// --- Trial Definitions ---
const titleScreen = {
    type: jsPsychHtmlKeyboardResponse,
    stimulus: `
        <div style="width: 100%; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center; background-color: #0c0c0c; color: #fff; font-family: 'Arial', sans-serif; cursor: pointer;">
            <h1 style="color: #ff9900; font-size: 48px; text-shadow: 0 0 10px rgba(255,153,0,0.5);">EXOBOUND v2.0</h1>
            <h2 style="color: #66ccff; margin-top: -10px;">TACTICAL FLEET COMMAND</h2>
            <p style="color: #ff9900; font-size: 24px; margin-top: 80px; animation: pulse 1.5s infinite;">Click to Begin</p>
        </div>
        <style> @keyframes pulse { 0% { opacity: 0.7; } 50% { opacity: 1; } 100% { opacity: 0.7; } } body, html {width: 100%; height: 100%; margin: 0; padding: 0;} </style>
    `,
    choices: 'NO_KEYS',
    on_load: function() {
        document.querySelector('#jspsych-content').addEventListener('click', () => jsPsych.finishTrial(), { once: true });
    }
};

const consentForm = {
    type: jsPsychHtmlButtonResponse,
    stimulus: `
        <div style="max-width: 800px; margin: auto; text-align: left;">
            <h1>Research Consent Form</h1>
            <p>You are invited to participate in a research study on decision-making in complex environments. Your participation is voluntary. The session will take approximately 15-20 minutes. Your responses will be kept completely anonymous.</p>
            <div class="consent-checkbox" style="margin-top: 20px;">
                <input type="checkbox" id="consent-checkbox" required>
                <label for="consent-checkbox">I have read and understood the above information and agree to participate in this study.</label>
            </div>
        </div>
    `,
    choices: ['I Consent to Participate'],
    on_load: function() {
        const consentButton = document.querySelector('.jspsych-btn');
        consentButton.disabled = true;
        document.getElementById('consent-checkbox').addEventListener('change', function() {
            consentButton.disabled = !this.checked;
        });
    }
};

const missionBriefing = {
    type: jsPsychHtmlKeyboardResponse,
    stimulus: `
        <div style="max-width: 800px; margin: auto; text-align: left; cursor: pointer;">
            <h1>Mission Briefing</h1>
            <p>Your mission is to defend the planet from an alien-infested asteroid.</p>
            <p>You will control a targeting reticle with your mouse. Use it to choose between targeting the Main Asteroid or the smaller, faster Raider ships that attack your fleet.</p>
            <p style="color: #ff9900; font-size: 18px; margin-top: 30px; text-align: center;">Click to start the game tutorial</p>
        </div>
    `,
    choices: 'NO_KEYS',
    on_load: function() {
        document.querySelector('#jspsych-content').addEventListener('click', () => jsPsych.finishTrial(), { once: true });
    }
};

const phaserTrial = {
    type: jsPsychHtmlKeyboardResponse,
    stimulus: '<div id="jspsych-phaser-game-container" style="width:1024px; height:768px; margin:auto;"></div>',
    choices: "NO_KEYS",
    trial_duration: null, // Let Phaser control when the trial ends
    on_load: function() {
        fetch('trials.json')
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                gameDataManager.initialize(data);
                console.log('GameDataManager initialized with data:', data);
                
                const config = {
                    type: Phaser.AUTO,
                    width: 1024,
                    height: 768,
                    parent: 'jspsych-phaser-game-container',
                    backgroundColor: '#0c0c0c',
                    scene: [BootScene, GameScene, TutorialUIScene, HUDScene, FeedbackSceneV2],
                    callbacks: {
                        preBoot: function(game) {
                            game.registry.set('gameDataManager', gameDataManager);
                            game.registry.set('jsPsych', jsPsych); // Make jsPsych instance available to scenes
                        }
                    }
                };
                
                const game = new Phaser.Game(config);
            })
            .catch(error => {
                console.error('CRITICAL ERROR:', error);
                document.getElementById('jspsych-phaser-game-container').innerHTML = '<h1>SYSTEM ERROR</h1><p>Could not load critical mission file: <strong>trials.json</strong></p>';
            });
    }
};

// This is the correct, restored timeline
const timeline = [titleScreen, consentForm, missionBriefing, phaserTrial];

jsPsych.run(timeline);
