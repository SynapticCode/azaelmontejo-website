// Component for displaying scores in the feedback scene
export default class ScoreDisplay {
    constructor(scene) {
        this.scene = scene;
        this.scoreContainer = scene.add.container(0, 0);
        this.scoreContainer.setDepth(5);
        
        // Initialize with default styles
        this.styles = {
            title: {
                font: 'bold 24px Arial',
                fill: '#ffffff',
                align: 'center'
            },
            score: {
                font: 'bold 36px Arial',
                fill: '#ffff00',
                align: 'center'
            },
            description: {
                font: '18px Arial',
                fill: '#cccccc',
                align: 'center'
            }
        };
        
        console.log('ScoreDisplay initialized');
    }
    
    showScores(threatNeutralized, fleetIntegrity) {
        try {
            // Clear any existing score elements
            this.scoreContainer.removeAll(true);
            
            const centerX = this.scene.cameras.main.width / 2;
            const centerY = this.scene.cameras.main.height / 2;
            
            // Create title
            const title = this.scene.add.text(
                centerX, 
                centerY - 150, 
                'MISSION RESULTS', 
                this.styles.title
            ).setOrigin(0.5);
            
            // Create threat neutralized score
            const threatTitle = this.scene.add.text(
                centerX - 150, 
                centerY - 80, 
                'THREAT NEUTRALIZED', 
                this.styles.title
            ).setOrigin(0.5);
            
            const threatScore = this.scene.add.text(
                centerX - 150, 
                centerY - 40, 
                `${threatNeutralized}%`, 
                this.styles.score
            ).setOrigin(0.5);
            
            const threatDesc = this.scene.add.text(
                centerX - 150, 
                centerY, 
                'Damage to asteroid\nand enemy ships', 
                this.styles.description
            ).setOrigin(0.5);
            
            // Create fleet integrity score
            const fleetTitle = this.scene.add.text(
                centerX + 150, 
                centerY - 80, 
                'FLEET INTEGRITY', 
                this.styles.title
            ).setOrigin(0.5);
            
            const fleetScore = this.scene.add.text(
                centerX + 150, 
                centerY - 40, 
                `${fleetIntegrity}%`, 
                this.styles.score
            ).setOrigin(0.5);
            
            const fleetDesc = this.scene.add.text(
                centerX + 150, 
                centerY, 
                'Allied ships\nremaining', 
                this.styles.description
            ).setOrigin(0.5);
            
            // Add all elements to the container
            this.scoreContainer.add([
                title, 
                threatTitle, threatScore, threatDesc,
                fleetTitle, fleetScore, fleetDesc
            ]);
            
            // Add animations
            this.animateScores();
            
            console.log('Scores displayed:', { threatNeutralized, fleetIntegrity });
        } catch (error) {
            console.error('Error showing scores:', error);
            this.showFallbackScores(threatNeutralized, fleetIntegrity);
        }
    }
    
    animateScores() {
        try {
            // Get all text objects in the container
            const elements = this.scoreContainer.getAll();
            
            // Set initial state
            elements.forEach(element => {
                element.setAlpha(0);
                element.y -= 20;
            });
            
            // Animate each element with a slight delay between them
            elements.forEach((element, index) => {
                this.scene.tweens.add({
                    targets: element,
                    alpha: 1,
                    y: element.y + 20,
                    ease: 'Power2',
                    duration: 500,
                    delay: index * 100
                });
            });
        } catch (error) {
            console.error('Error animating scores:', error);
            // Make all elements visible without animation as fallback
            this.scoreContainer.getAll().forEach(element => {
                element.setAlpha(1);
            });
        }
    }
    
    showFallbackScores(threatNeutralized, fleetIntegrity) {
        // Simple fallback display without fancy formatting
        this.scoreContainer.removeAll(true);
        
        const centerX = this.scene.cameras.main.width / 2;
        const centerY = this.scene.cameras.main.height / 2;
        
        const scoreText = this.scene.add.text(
            centerX,
            centerY - 50,
            `MISSION RESULTS\n\nThreat Neutralized: ${threatNeutralized}%\nFleet Integrity: ${fleetIntegrity}%`,
            {
                font: '20px Arial',
                fill: '#ffffff',
                align: 'center'
            }
        ).setOrigin(0.5);
        
        this.scoreContainer.add(scoreText);
    }
    
    hide() {
        // Hide the score container
        this.scoreContainer.setVisible(false);
    }
    
    show() {
        // Show the score container
        this.scoreContainer.setVisible(true);
    }
}
