// Component for displaying battle results
export default class ResultsDisplay {
    constructor(scene) {
        this.scene = scene;
    }
    
    displayResults(enemyShips, playerShips, playerTarget) {
        // Calculate scores
        const destroyedEnemies = enemyShips.filter(ship => ship.status === 'destroyed').length;
        const destroyedFriendlies = playerShips.filter(ship => ship.status === 'destroyed').length;
        
        // Display threat neutralized score
        this.scene.add.text(this.scene.cameras.main.width * 0.25, this.scene.cameras.main.height * 0.4, 
            `Threat Neutralized: ${destroyedEnemies}`, {
            fontFamily: 'Arial',
            fontSize: '20px',
            color: '#00ff00'
        }).setOrigin(0.5, 0);
        
        // Display fleet integrity score
        this.scene.add.text(this.scene.cameras.main.width * 0.75, this.scene.cameras.main.height * 0.4, 
            `Fleet Integrity: ${playerShips.length - destroyedFriendlies}/${playerShips.length}`, {
            fontFamily: 'Arial',
            fontSize: '20px',
            color: '#00ff00'
        }).setOrigin(0.5, 0);
        
        // Update statistics in GameDataManager
        if (this.scene.gameDataManager) {
            if (playerTarget.type === 'asteroid' && enemyShips.length > 0) {
                // Player failed to adapt by shooting asteroid when enemies were present
                this.scene.gameDataManager.environmentalLoss += 1;
            }
            
            // Update teamwork loss based on destroyed friendly ships
            this.scene.gameDataManager.teamworkLoss += destroyedFriendlies;
        }
    }
    
    addContinueButton(callback) {
        // Add continue button
        const continueButton = this.scene.add.text(
            this.scene.cameras.main.width / 2, 
            this.scene.cameras.main.height * 0.9, 
            'CONTINUE', {
                fontFamily: 'Arial',
                fontSize: '24px',
                color: '#ffffff',
                backgroundColor: '#004466',
                padding: { x: 20, y: 10 }
            }
        ).setOrigin(0.5, 0.5);
        
        // Make button interactive
        continueButton.setInteractive({ useHandCursor: true });
        
        // Add hover effect
        continueButton.on('pointerover', () => {
            continueButton.setStyle({ backgroundColor: '#0066aa' });
        });
        
        continueButton.on('pointerout', () => {
            continueButton.setStyle({ backgroundColor: '#004466' });
        });
        
        // Add click handler
        continueButton.on('pointerdown', () => {
            // Play click sound if available
            if (this.scene.sound.get('click')) {
                this.scene.sound.play('click');
            }
            
            // Execute callback
            if (callback && typeof callback === 'function') {
                callback();
            }
        });
        
        return continueButton;
    }
}
