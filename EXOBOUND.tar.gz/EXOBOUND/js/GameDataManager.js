class GameDataManager {
    constructor(trialData) {
        // Initialize with trial data
        this.trialData = trialData || [];
        this.totalTrials = this.trialData.length;
        
        // Initialize game state
        this.currentTrialIndex = 0;
        this.playerFleet = [];
        this.alienFleet = [];
        this.asteroidHealth = 100;
        this.reinforcementsAvailable = true;
        
        // Initialize statistics
        this.environmentalLoss = 0;
        this.teamworkLoss = 0;
        this.reception = 0.7; // Default reception rate (70%)
        
        console.log('GameDataManager initialized with trial data:', this.trialData);
    }
    
    // Add the missing initialize method that experiment.js is trying to call
    initialize(data) {
        if (data) {
            // Update trial data if provided
            this.trialData = data;
            this.totalTrials = this.trialData.length;
        }
        
        // Reset game state
        this.reset();
        
        // Initialize player fleet
        this.initializePlayerFleet();
        
        console.log('GameDataManager initialized with data:', this.trialData);
        return this;
    }
    
    // Initialize the player fleet with default ships
    initializePlayerFleet() {
        // Create three default ships
        this.playerFleet = [
            { id: 0, sprite: null, status: 'active', type: 'allied_ship_green' },
            { id: 1, sprite: null, status: 'active', type: 'allied_ship_blue' },
            { id: 2, sprite: null, status: 'active', type: 'allied_ship_orange' }
        ];
    }
    
    // Set sprite references for the player fleet
    setPlayerFleetSprites(sprites) {
        if (!sprites || sprites.length === 0) return;
        
        sprites.forEach((sprite, index) => {
            if (index < this.playerFleet.length) {
                this.playerFleet[index].sprite = sprite;
            }
        });
    }
    
    // Set up a trial based on the trial index
    setupTrial(trialIndex) {
        if (trialIndex >= this.totalTrials) {
            console.error('Trial index out of bounds:', trialIndex);
            return null;
        }
        
        // Set current trial index
        this.currentTrialIndex = trialIndex;
        
        // Get trial data
        const trial = this.trialData[trialIndex];
        
        // Set asteroid health if specified
        if (trial.asteroidHealth !== undefined) {
            this.asteroidHealth = trial.asteroidHealth;
        }
        
        // Check if a new alien should spawn
        if (trial.spawnRaider) {
            this.spawnRaider(trial.raiderType, trial.raiderPosition);
        }
        
        console.log(`Trial ${trialIndex} setup complete:`, trial);
        return trial;
    }
    
    // Spawn a new alien raider
    spawnRaider(type = 'red', position = { x: 0.5, y: 0.3 }) {
        // Generate a unique ID for the raider
        const id = this.alienFleet.length + 1;
        
        // Create the raider object
        const raider = {
            id: id,
            type: `raider_${type}`,
            status: 'active',
            position: position,
            health: 1,
            sprite: null
        };
        
        // Add to alien fleet
        this.alienFleet.push(raider);
        
        console.log('Spawned new raider:', raider);
        return raider;
    }
    
    // Set sprite reference for an alien
    setAlienSprite(alienId, sprite) {
        const alien = this.alienFleet.find(a => a.id === alienId);
        if (alien) {
            alien.sprite = sprite;
        }
    }
    
    // Destroy an alien
    destroyAlien(alienId) {
        const alien = this.alienFleet.find(a => a.id === alienId);
        if (alien) {
            alien.status = 'destroyed';
            return true;
        }
        return false;
    }
    
    // Destroy a friendly ship
    destroyFriendlyShip(shipId) {
        const ship = this.playerFleet.find(s => s.id === shipId);
        if (ship) {
            ship.status = 'destroyed';
            this.teamworkLoss += 1;
            return true;
        }
        return false;
    }
    
    // Damage the asteroid
    damageAsteroid(amount) {
        this.asteroidHealth -= amount;
        if (this.asteroidHealth < 0) {
            this.asteroidHealth = 0;
        }
        return this.asteroidHealth;
    }
    
    // Use reinforcements
    useReinforcements() {
        if (this.reinforcementsAvailable) {
            this.reinforcementsAvailable = false;
            return true;
        }
        return false;
    }
    
    // Get active aliens
    getActiveAliens() {
        return this.alienFleet.filter(alien => alien.status === 'active');
    }
    
    // Get active player ships
    getActivePlayerShips() {
        return this.playerFleet.filter(ship => ship.status === 'active');
    }
    
    // Reset the game state for a new session
    reset() {
        this.currentTrialIndex = 0;
        this.playerFleet = [];
        this.alienFleet = [];
        this.asteroidHealth = 100;
        this.reinforcementsAvailable = true;
        this.environmentalLoss = 0;
        this.teamworkLoss = 0;
    }
}

export default GameDataManager;
